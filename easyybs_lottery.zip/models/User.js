import mongoose from "mongoose";

const DEFAULT_PROFILE_PIC = "https://dummyimage.com/256x256/d9d9d9/4a4a4a.png&text=User";

const userSchema = new mongoose.Schema(
  {
    email: { 
      type: String, 
      required: true, 
      unique: true, 
      index: true 
    },
    
    username: { 
      type: String,
      required: true,
    },
    password: {
        type: String,
        required: true,
        select: false
    },
    profilePic: { 
      type: String,
      default: DEFAULT_PROFILE_PIC,
    },


    isBanned: {
      type: Boolean,
      default: false
    },
    subscriptionExpires: {
      type: Date,
      default: null,
      index: true
    },
    subscriptionCancelCount: {
      type: Number,
      default: 0,
    },
    isSubscriptionBanned: {
      type: Boolean,
      default: false,
    },
    isActive: {
      type: Boolean,
      default: false
    },
    points: {
      type: Number,
      default: 0,
    },
    trackingHourlyLimit: {
      type: Number,
      default: parseInt(process.env.LIMITER_INSIGHT_HOURLY_MAX) || 10,
    },
    allowanceLimit: {
      type: Number,
      default: parseInt(process.env.ALLOWANCE_LIMIT_DEFAULT) || 10,
    },
  },
  { timestamps: true }
);

// Index for leaderboard

userSchema.methods.isSubscriptionActive = function() {
  return this.subscriptionExpires && new Date(this.subscriptionExpires) > new Date();
};

const User = mongoose.model("User", userSchema);
export default User;
