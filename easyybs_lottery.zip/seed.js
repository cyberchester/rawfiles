import "dotenv/config";
import { readFileSync } from "fs";
import mongoose from "mongoose";
import connectDB from "./config/db.js";
import Ticket from "./models/Ticket.js";
import User from "./models/User.js";
import Post from "./models/Post.js";

const data = JSON.parse(readFileSync("./lot-filtered.json", "utf-8"));

const seed = async () => {
  await connectDB();

  // Drop existing
  await Ticket.deleteMany({});
  await User.deleteMany({});
  await Post.deleteMany({});

  // Collect unique user & post IDs
  const userIds = [...new Set(data.map((t) => t.user.$oid))];
  const postIds = [...new Set(data.map((t) => t.post.$oid))];

  // Create dummy users & posts
  const users = userIds.map((id, i) => ({
    _id: new mongoose.Types.ObjectId(id),
    username: `user_${i + 1}`,
  }));
  const posts = postIds.map((id) => ({
    _id: new mongoose.Types.ObjectId(id),
  }));

  await User.insertMany(users);
  await Post.insertMany(posts);

  // Create tickets
  const tickets = data.map((t) => ({
    _id: new mongoose.Types.ObjectId(t._id.$oid),
    post: new mongoose.Types.ObjectId(t.post.$oid),
    user: new mongoose.Types.ObjectId(t.user.$oid),
    content: t.content,
    createdAt: new Date(t.createdAt.$date),
    updatedAt: new Date(t.updatedAt.$date),
  }));

  await Ticket.insertMany(tickets);

  console.log(`Seeded: ${users.length} users, ${posts.length} posts, ${tickets.length} tickets`);
  process.exit(0);
};

seed();
