import "dotenv/config";
import express from "express";
import connectDB from "./config/db.js";
import Ticket from "./models/Ticket.js";
import "./models/User.js"; // needed for populate("user")

const app = express();

const toMyanmar = (str) =>
  str.replace(/[0-9]/g, (d) => "၀၁၂၃၄၅၆၇၈၉"[d]);

const maskEmail = (email) => {
  if (!email) return "—";
  const at = email.indexOf("@");
  if (at === -1) return email;
  const local = email.slice(0, at);
  const domain = email.slice(at);
  if (local.length <= 5) return email;
  return "*".repeat(local.length - 5) + local.slice(-5) + domain;
};

// Connect to MongoDB
connectDB();

// View engine
app.set("view engine", "ejs");
app.use(express.static("public"));

// Home — show ticket content + username
app.get("/", async (req, res) => {
  try {
    const tickets = await Ticket.find().populate("user", "username email").lean();
    tickets.forEach((t) => {
      t.content = toMyanmar(t.content);
      t.maskedEmail = maskEmail(t.user?.email);
    });
    res.render("index", { tickets });
  } catch (err) {
    res.status(500).send("Error loading tickets");
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
